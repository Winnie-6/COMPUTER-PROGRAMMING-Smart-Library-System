package utils;

import java.util.HashMap;

public class IDGenerator {

    private static HashMap<String, Integer> counters = new HashMap<String, Integer>();

    private IDGenerator() {
    }

    public static String nextId(String prefix) {
        Integer current = counters.get(prefix);
        if (current == null) {
            current = 100;
        }
        counters.put(prefix, current + 1);
        return prefix + current;
    }

    // when we load old data off disk, make sure new ids don't collide with it
    public static void absorb(String prefix, String id) {
        if (id == null || !id.startsWith(prefix)) {
            return;
        }
        String numberPart = id.substring(prefix.length());
        int number;
        try {
            number = Integer.parseInt(numberPart);
        } catch (NumberFormatException e) {
            return;
        }
        Integer current = counters.get(prefix);
        if (current == null || number >= current) {
            counters.put(prefix, number + 1);
        }
    }
}
