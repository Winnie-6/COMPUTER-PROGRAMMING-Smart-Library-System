package utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import model.Book;
import model.BorrowRecord;
import model.Journal;
import model.LibraryDatabase;
import model.LibraryItem;
import model.Magazine;
import model.UserAccount;

public class FileHandler {

    private static final String CATALOG_FILE = "catalog.txt";
    private static final String ACCOUNTS_FILE = "accounts.txt";
    private static final String RECORDS_FILE = "records.txt";
    private static final String WAITLISTS_FILE = "waitlists.txt";

    private FileHandler() {
    }

    // returns false and touches nothing if none of the four files are present
    public static boolean load(String folderPath, LibraryDatabase db) {
        File folder = new File(folderPath);
        File catalog = new File(folder, CATALOG_FILE);
        File accounts = new File(folder, ACCOUNTS_FILE);
        File records = new File(folder, RECORDS_FILE);
        File waitlists = new File(folder, WAITLISTS_FILE);

        if (!catalog.exists() && !accounts.exists() && !records.exists() && !waitlists.exists()) {
            return false;
        }

        loadCatalog(catalog, db);
        loadAccounts(accounts, db);
        loadRecords(records, db);
        loadWaitlists(waitlists, db);
        return true;
    }

    public static void save(String folderPath, LibraryDatabase db) {
        File folder = new File(folderPath);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        saveCatalog(new File(folder, CATALOG_FILE), db);
        saveAccounts(new File(folder, ACCOUNTS_FILE), db);
        saveRecords(new File(folder, RECORDS_FILE), db);
        saveWaitlists(new File(folder, WAITLISTS_FILE), db);
    }

    private static void loadCatalog(File file, LibraryDatabase db) {
        if (!file.exists()) {
            return;
        }
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().length() == 0) {
                    continue;
                }
                try {
                    String[] parts = line.split("\t", -1);
                    String kind = parts[0];
                    String id = parts[1];
                    String title = parts[2];
                    String author = parts[3];
                    int year = Integer.parseInt(parts[4]);
                    String holder = parts[7].length() == 0 ? null : parts[7];

                    LibraryItem item = null;
                    if (kind.equals("Book")) {
                        item = new Book(id, title, author, year, parts[5], parts[6]);
                    } else if (kind.equals("Magazine")) {
                        item = new Magazine(id, title, author, year, Integer.parseInt(parts[5]), parts[6]);
                    } else if (kind.equals("Journal")) {
                        item = new Journal(id, title, author, year, Integer.parseInt(parts[5]), parts[6]);
                    }
                    if (item != null) {
                        item.setCurrentHolder(holder);
                        db.addItem(item);
                        IDGenerator.absorb(prefixFor(kind), id);
                    }
                } catch (Exception lineProblem) {
                    System.err.println("Skipping a bad catalog line: " + line);
                }
            }
        } catch (IOException e) {
            System.err.println("Could not read catalog file: " + e.getMessage());
        } finally {
            closeQuietly(reader);
        }
    }

    private static String prefixFor(String kind) {
        if (kind.equals("Book")) {
            return "BK";
        }
        if (kind.equals("Magazine")) {
            return "MG";
        }
        return "JN";
    }

    private static void loadAccounts(File file, LibraryDatabase db) {
        if (!file.exists()) {
            return;
        }
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().length() == 0) {
                    continue;
                }
                try {
                    String[] parts = line.split("\t", -1);
                    String userId = parts[0];
                    String fullName = parts[1];
                    db.addUser(new UserAccount(userId, fullName));
                    IDGenerator.absorb("US", userId);
                } catch (Exception lineProblem) {
                    System.err.println("Skipping a bad accounts line: " + line);
                }
            }
        } catch (IOException e) {
            System.err.println("Could not read accounts file: " + e.getMessage());
        } finally {
            closeQuietly(reader);
        }
    }

    private static void loadRecords(File file, LibraryDatabase db) {
        if (!file.exists()) {
            return;
        }
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().length() == 0) {
                    continue;
                }
                try {
                    String[] parts = line.split("\t", -1);
                    String itemId = parts[0];
                    String userId = parts[1];
                    LocalDate taken = LocalDate.parse(parts[2]);
                    LocalDate due = LocalDate.parse(parts[3]);
                    BorrowRecord record = new BorrowRecord(itemId, userId, taken, due);
                    if (parts[4].length() > 0) {
                        record.setDateReturned(LocalDate.parse(parts[4]));
                    }
                    UserAccount owner = db.getUser(userId);
                    if (owner != null) {
                        owner.addRecord(record);
                    }
                } catch (Exception lineProblem) {
                    System.err.println("Skipping a bad records line: " + line);
                }
            }
        } catch (IOException e) {
            System.err.println("Could not read records file: " + e.getMessage());
        } finally {
            closeQuietly(reader);
        }
    }

    private static void loadWaitlists(File file, LibraryDatabase db) {
        if (!file.exists()) {
            return;
        }
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().length() == 0) {
                    continue;
                }
                try {
                    String[] parts = line.split("\t", -1);
                    String itemId = parts[0];
                    if (parts.length > 1 && parts[1].length() > 0) {
                        String[] userIds = parts[1].split(",");
                        for (int i = 0; i < userIds.length; i++) {
                            db.joinWaitlist(itemId, userIds[i]);
                        }
                    }
                } catch (Exception lineProblem) {
                    System.err.println("Skipping a bad waitlists line: " + line);
                }
            }
        } catch (IOException e) {
            System.err.println("Could not read waitlists file: " + e.getMessage());
        } finally {
            closeQuietly(reader);
        }
    }

    private static void saveCatalog(File file, LibraryDatabase db) {
        PrintWriter writer = null;
        try {
            writer = new PrintWriter(new FileWriter(file));
            List<LibraryItem> items = db.getItems();
            for (int i = 0; i < items.size(); i++) {
                writer.println(items.get(i).getSaveLine());
            }
        } catch (IOException e) {
            System.err.println("Could not write catalog file: " + e.getMessage());
        } finally {
            closeQuietly(writer);
        }
    }

    private static void saveAccounts(File file, LibraryDatabase db) {
        PrintWriter writer = null;
        try {
            writer = new PrintWriter(new FileWriter(file));
            List<UserAccount> users = db.getUsers();
            for (int i = 0; i < users.size(); i++) {
                UserAccount u = users.get(i);
                writer.println(u.getUserId() + "\t" + u.getFullName());
            }
        } catch (IOException e) {
            System.err.println("Could not write accounts file: " + e.getMessage());
        } finally {
            closeQuietly(writer);
        }
    }

    private static void saveRecords(File file, LibraryDatabase db) {
        PrintWriter writer = null;
        try {
            writer = new PrintWriter(new FileWriter(file));
            List<UserAccount> users = db.getUsers();
            for (int i = 0; i < users.size(); i++) {
                List<BorrowRecord> history = users.get(i).getHistory();
                for (int j = 0; j < history.size(); j++) {
                    BorrowRecord r = history.get(j);
                    String returned = r.getDateReturned() == null ? "" : r.getDateReturned().toString();
                    writer.println(r.getItemId() + "\t" + r.getUserId() + "\t" + r.getDateTaken()
                            + "\t" + r.getDateDue() + "\t" + returned);
                }
            }
        } catch (IOException e) {
            System.err.println("Could not write records file: " + e.getMessage());
        } finally {
            closeQuietly(writer);
        }
    }

    private static void saveWaitlists(File file, LibraryDatabase db) {
        PrintWriter writer = null;
        try {
            writer = new PrintWriter(new FileWriter(file));
            Map<String, LinkedList<String>> waitlists = db.getWaitlists();
            for (Map.Entry<String, LinkedList<String>> entry : waitlists.entrySet()) {
                LinkedList<String> line = entry.getValue();
                if (line.isEmpty()) {
                    continue;
                }
                StringBuilder joined = new StringBuilder();
                for (int i = 0; i < line.size(); i++) {
                    if (i > 0) {
                        joined.append(",");
                    }
                    joined.append(line.get(i));
                }
                writer.println(entry.getKey() + "\t" + joined.toString());
            }
        } catch (IOException e) {
            System.err.println("Could not write waitlists file: " + e.getMessage());
        } finally {
            closeQuietly(writer);
        }
    }

    private static void closeQuietly(java.io.Closeable c) {
        if (c == null) {
            return;
        }
        try {
            c.close();
        } catch (IOException ignored) {
            // nothing useful we can do here
        }
    }
}
