// small fixed-size cache that remembers the most looked-at items
package utils;

public class AccessCache {

    private static final int CAPACITY = 6;

    // one slot in the cache - which item, its title, and how many hits it has
    private class CacheSlot {
        String id;
        String title;
        int hits;

        CacheSlot(String id, String title) {
            this.id = id;
            this.title = title;
            this.hits = 1;
        }
    }

    private CacheSlot[] slots;
    private int used; // how many of the slots are actually filled

    public AccessCache() {
        slots = new CacheSlot[CAPACITY];
        used = 0;
    }

    // record that this item was looked at - keeps the array sorted by hits desc
    public void touch(String id, String title) {
        int index = indexOf(id);
        if (index >= 0) {
            slots[index].hits++;
            bubbleLeft(index);
            return;
        }
        if (used < CAPACITY) {
            slots[used] = new CacheSlot(id, title);
            used++;
            bubbleLeft(used - 1);
            return;
        }
        // cache is full - the last slot is the least popular, so it goes
        slots[CAPACITY - 1] = new CacheSlot(id, title);
        bubbleLeft(CAPACITY - 1);
    }

    private int indexOf(String id) {
        for (int i = 0; i < used; i++) {
            if (slots[i].id.equals(id)) {
                return i;
            }
        }
        return -1;
    }

    private void bubbleLeft(int index) {
        while (index > 0 && slots[index - 1].hits < slots[index].hits) {
            CacheSlot temp = slots[index - 1];
            slots[index - 1] = slots[index];
            slots[index] = temp;
            index--;
        }
    }

    public String[] topEntries() {
        String[] lines = new String[used];
        for (int i = 0; i < used; i++) {
            lines[i] = slots[i].id + " - " + slots[i].title + " (" + slots[i].hits + " views)";
        }
        return lines;
    }
}
