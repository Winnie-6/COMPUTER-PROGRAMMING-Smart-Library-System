// base class for everything the library keeps on its shelves
package model;

public abstract class LibraryItem implements Borrowable {

    private String itemId;
    private String title;
    private String author;
    private int year;
    private String currentHolder; // null means nobody has it right now

    public LibraryItem(String itemId, String title, String author, int year) {
        this.itemId = itemId;
        this.title = title;
        this.author = author;
        this.year = year;
        this.currentHolder = null;
    }

    public boolean isOnShelf() {
        return currentHolder == null;
    }

    public void lendTo(String userId) {
        this.currentHolder = userId;
    }

    public void handBack() {
        this.currentHolder = null;
    }

    // each kind of item has its own loan length, so subclasses fill this in
    public abstract int borrowDays();

    // short tag used in the table (e.g. "Book")
    public abstract String getType();

    // a couple of lines shown in the details panel
    public abstract String getSummary();

    // one tab-separated line this item can be written to disk as
    public abstract String getSaveLine();

    public String getItemId() {
        return itemId;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getYear() {
        return year;
    }

    public String getCurrentHolder() {
        return currentHolder;
    }

    public void setCurrentHolder(String currentHolder) {
        this.currentHolder = currentHolder;
    }
}
