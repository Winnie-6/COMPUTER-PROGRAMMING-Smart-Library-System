package model;

public class Journal extends LibraryItem {

    private int volumeNo;
    private String fieldName;

    public Journal(String itemId, String title, String author, int year, int volumeNo, String fieldName) {
        super(itemId, title, author, year);
        this.volumeNo = volumeNo;
        this.fieldName = fieldName;
    }

    public int borrowDays() {
        return 14;
    }

    public String getType() {
        return "Journal";
    }

    public String getSummary() {
        return "Journal: " + getTitle() + " (" + getYear() + ")\n"
                + "Volume " + volumeNo + " - Field: " + fieldName;
    }

    public String getSaveLine() {
        return "Journal\t" + getItemId() + "\t" + getTitle() + "\t" + getAuthor() + "\t" + getYear()
                + "\t" + volumeNo + "\t" + fieldName + "\t" + emptyIfNull(getCurrentHolder());
    }

    private String emptyIfNull(String s) {
        return s == null ? "" : s;
    }

    public int getVolumeNo() {
        return volumeNo;
    }

    public String getFieldName() {
        return fieldName;
    }
}
