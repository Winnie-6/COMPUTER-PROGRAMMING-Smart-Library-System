// a library member and everything they have ever borrowed
package model;

import java.util.ArrayList;
import java.util.List;

public class UserAccount {

    private String userId;
    private String fullName;
    private List<BorrowRecord> history;

    public UserAccount(String userId, String fullName) {
        this.userId = userId;
        this.fullName = fullName;
        this.history = new ArrayList<BorrowRecord>();
    }

    public void addRecord(BorrowRecord record) {
        history.add(record);
    }

    // count how many things this user has out right now by walking the history
    public int activeLoanCount() {
        int count = 0;
        for (int i = 0; i < history.size(); i++) {
            if (history.get(i).isStillOut()) {
                count++;
            }
        }
        return count;
    }

    // find the open record for a given item, or null if they don't have it
    public BorrowRecord findOpenRecordFor(String itemId) {
        for (int i = 0; i < history.size(); i++) {
            BorrowRecord r = history.get(i);
            if (r.getItemId().equals(itemId) && r.isStillOut()) {
                return r;
            }
        }
        return null;
    }

    public String getUserId() {
        return userId;
    }

    public String getFullName() {
        return fullName;
    }

    public List<BorrowRecord> getHistory() {
        return history;
    }
}
