package model;

public class Book extends LibraryItem {

    private String isbn;
    private String subject;

    public Book(String itemId, String title, String author, int year, String isbn, String subject) {
        super(itemId, title, author, year);
        this.isbn = isbn;
        this.subject = subject;
    }

    public int borrowDays() {
        return 21;
    }

    public String getType() {
        return "Book";
    }

    public String getSummary() {
        return "Book: " + getTitle() + " by " + getAuthor() + " (" + getYear() + ")\n"
                + "ISBN: " + isbn + "\nSubject: " + subject;
    }

    public String getSaveLine() {
        return "Book\t" + getItemId() + "\t" + getTitle() + "\t" + getAuthor() + "\t" + getYear()
                + "\t" + isbn + "\t" + subject + "\t" + emptyIfNull(getCurrentHolder());
    }

    private String emptyIfNull(String s) {
        return s == null ? "" : s;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getSubject() {
        return subject;
    }
}
