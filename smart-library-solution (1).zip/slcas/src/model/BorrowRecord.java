// one line of a user's borrowing history
package model;

import java.time.LocalDate;

public class BorrowRecord {

    private String itemId;
    private String userId;
    private LocalDate dateTaken;
    private LocalDate dateDue;
    private LocalDate dateReturned; // null while the item is still out

    public BorrowRecord(String itemId, String userId, LocalDate dateTaken, LocalDate dateDue) {
        this.itemId = itemId;
        this.userId = userId;
        this.dateTaken = dateTaken;
        this.dateDue = dateDue;
        this.dateReturned = null;
    }

    public boolean isStillOut() {
        return dateReturned == null;
    }

    public boolean isOverdue(LocalDate today) {
        if (!isStillOut()) {
            return false;
        }
        return today.isAfter(dateDue);
    }

    public int daysLate(LocalDate today) {
        if (!isOverdue(today)) {
            return 0;
        }
        long diff = today.toEpochDay() - dateDue.toEpochDay();
        return (int) diff;
    }

    public String getItemId() {
        return itemId;
    }

    public String getUserId() {
        return userId;
    }

    public LocalDate getDateTaken() {
        return dateTaken;
    }

    public LocalDate getDateDue() {
        return dateDue;
    }

    public LocalDate getDateReturned() {
        return dateReturned;
    }

    public void setDateReturned(LocalDate dateReturned) {
        this.dateReturned = dateReturned;
    }
}
