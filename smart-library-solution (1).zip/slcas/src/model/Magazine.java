// a magazine issue - short 7 day loan
package model;

public class Magazine extends LibraryItem {

    private int issueNo;
    private String monthName;

    public Magazine(String itemId, String title, String author, int year, int issueNo, String monthName) {
        super(itemId, title, author, year);
        this.issueNo = issueNo;
        this.monthName = monthName;
    }

    public int borrowDays() {
        return 7;
    }

    public String getType() {
        return "Magazine";
    }

    public String getSummary() {
        return "Magazine: " + getTitle() + " (" + getYear() + ")\n"
                + "Issue #" + issueNo + " - " + monthName;
    }

    public String getSaveLine() {
        return "Magazine\t" + getItemId() + "\t" + getTitle() + "\t" + getAuthor() + "\t" + getYear()
                + "\t" + issueNo + "\t" + monthName + "\t" + emptyIfNull(getCurrentHolder());
    }

    private String emptyIfNull(String s) {
        return s == null ? "" : s;
    }

    public int getIssueNo() {
        return issueNo;
    }

    public String getMonthName() {
        return monthName;
    }
}
