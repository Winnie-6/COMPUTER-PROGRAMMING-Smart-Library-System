package model;

public interface Borrowable {
    boolean isOnShelf();
    void lendTo(String userId);
    void handBack();
    int borrowDays();
}
