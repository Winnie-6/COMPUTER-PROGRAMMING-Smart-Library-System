package model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class LibraryDatabase {

    private ArrayList<LibraryItem> items;
    private HashMap<String, UserAccount> users;
    private HashMap<String, LinkedList<String>> waitlists;

    public LibraryDatabase() {
        items = new ArrayList<LibraryItem>();
        users = new HashMap<String, UserAccount>();
        waitlists = new HashMap<String, LinkedList<String>>();
    }

    public ArrayList<LibraryItem> getItems() {
        return items;
    }

    public List<UserAccount> getUsers() {
        return new ArrayList<UserAccount>(users.values());
    }

    public void addItem(LibraryItem item) {
        items.add(item);
    }

    public boolean removeItem(String itemId) {
        LibraryItem found = getItem(itemId);
        if (found == null) {
            return false;
        }
        items.remove(found);
        return true;
    }

    public LibraryItem getItem(String itemId) {
        if (itemId == null) {
            return null;
        }
        // just walk the list, nothing fancy needed for a small catalog
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).getItemId().equals(itemId)) {
                return items.get(i);
            }
        }
        return null;
    }

    public void addUser(UserAccount user) {
        users.put(user.getUserId(), user);
    }

    public UserAccount getUser(String userId) {
        if (userId == null) {
            return null;
        }
        return users.get(userId);
    }

    public BorrowRecord activeRecordFor(String itemId) {
        for (UserAccount u : users.values()) {
            BorrowRecord r = u.findOpenRecordFor(itemId);
            if (r != null) {
                return r;
            }
        }
        return null;
    }

    public void joinWaitlist(String itemId, String userId) {
        LinkedList<String> line = waitlists.get(itemId);
        if (line == null) {
            line = new LinkedList<String>();
            waitlists.put(itemId, line);
        }
        Queue<String> asQueue = line;
        asQueue.offer(userId);
    }

    // pop the next name in line for this item, or null if nobody is waiting
    public String nextInWaitlist(String itemId) {
        LinkedList<String> line = waitlists.get(itemId);
        if (line == null || line.isEmpty()) {
            return null;
        }
        Queue<String> asQueue = line;
        return asQueue.poll();
    }

    public boolean hasWaitlist(String itemId) {
        LinkedList<String> line = waitlists.get(itemId);
        return line != null && !line.isEmpty();
    }

    public void clearWaitlist(String itemId) {
        waitlists.remove(itemId);
    }

    public HashMap<String, LinkedList<String>> getWaitlists() {
        return waitlists;
    }
}
