package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import controller.SearchEngine;
import controller.SortTool;
import model.LibraryDatabase;
import model.LibraryItem;

public class SearchPanel extends JPanel {

    private MainWindow mainWindow;
    private LibraryDatabase db;

    private JTextField searchField;
    private JComboBox<String> searchByCombo;
    private JComboBox<String> sortFieldCombo;
    private JComboBox<String> algorithmCombo;
    private JTable resultsTable;
    private LibraryTableModel tableModel;

    public SearchPanel(MainWindow mainWindow) {
        this.mainWindow = mainWindow;
        this.db = mainWindow.getDb();
        buildUi();
    }

    public void setDatabase(LibraryDatabase db) {
        this.db = db;
    }

    private void buildUi() {
        setLayout(new BorderLayout(6, 6));
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JPanel controlsPanel = new JPanel();
        controlsPanel.setLayout(new javax.swing.BoxLayout(controlsPanel, javax.swing.BoxLayout.Y_AXIS));

        JPanel searchRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchField = new JTextField(18);
        searchField.setToolTipText("Type to filter live, press Enter for an exact search");
        searchByCombo = new JComboBox<String>(new String[]{"Title", "Author", "Type"});

        searchField.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { liveFilter(); }
            public void removeUpdate(DocumentEvent e) { liveFilter(); }
            public void changedUpdate(DocumentEvent e) { liveFilter(); }
        });
        searchField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                doExactSearch();
            }
        });

        searchRow.add(new JLabel("Search:"));
        searchRow.add(searchField);
        searchRow.add(new JLabel("in"));
        searchRow.add(searchByCombo);

        JPanel sortRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        sortFieldCombo = new JComboBox<String>(new String[]{"Title", "Author", "Year"});
        algorithmCombo = new JComboBox<String>(new String[]{"Insertion Sort", "Quick Sort"});
        algorithmCombo.setToolTipText("Pick which sorting algorithm runs");
        JButton sortButton = new JButton("Sort");
        sortButton.setMnemonic('T');
        sortButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                doSort();
            }
        });
        sortRow.add(new JLabel("Sort by:"));
        sortRow.add(sortFieldCombo);
        sortRow.add(new JLabel("using"));
        sortRow.add(algorithmCombo);
        sortRow.add(sortButton);

        controlsPanel.add(searchRow);
        controlsPanel.add(sortRow);
        add(controlsPanel, BorderLayout.NORTH);

        tableModel = new LibraryTableModel(db);
        resultsTable = new JTable(tableModel);
        resultsTable.getColumnModel().getColumn(5).setCellRenderer(tableModel.new StatusColumnRenderer());
        add(new JScrollPane(resultsTable), BorderLayout.CENTER);
    }

    // runs on every keystroke - just a quick narrowing filter, nothing fancy
    private void liveFilter() {
        String query = searchField.getText().trim();
        String searchBy = (String) searchByCombo.getSelectedItem();
        List<LibraryItem> results;
        if (query.length() == 0) {
            results = db.getItems();
        } else if (searchBy.equals("Author")) {
            results = new ArrayList<LibraryItem>();
            List<LibraryItem> all = db.getItems();
            for (int i = 0; i < all.size(); i++) {
                if (all.get(i).getAuthor().toLowerCase().contains(query.toLowerCase())) {
                    results.add(all.get(i));
                }
            }
        } else if (searchBy.equals("Type")) {
            results = SearchEngine.filterByType(db.getItems(), query);
        } else {
            results = SearchEngine.linearTitleSearch(db.getItems(), query);
        }
        showResults(results);
    }

    // Enter key - runs the actual algorithm we want to demonstrate for the field chosen
    private void doExactSearch() {
        String query = searchField.getText().trim();
        String searchBy = (String) searchByCombo.getSelectedItem();
        if (query.length() == 0) {
            return;
        }
        List<LibraryItem> results;
        String statusMessage;

        if (searchBy.equals("Title")) {
            if (mainWindow.isSortedByTitle()) {
                results = SearchEngine.binaryTitleSearch(db.getItems(), query);
                statusMessage = "Binary search (list is sorted by title) found " + results.size() + " match(es).";
            } else {
                results = SearchEngine.linearTitleSearch(db.getItems(), query);
                statusMessage = "Linear search (list isn't sorted by title) found " + results.size() + " match(es).";
            }
            for (int i = 0; i < results.size(); i++) {
                mainWindow.getCache().touch(results.get(i).getItemId(), results.get(i).getTitle());
            }
        } else if (searchBy.equals("Author")) {
            results = new ArrayList<LibraryItem>();
            SearchEngine.searchAuthor(db.getItems(), query, 0, results);
            statusMessage = "Recursive author search found " + results.size() + " match(es).";
        } else {
            results = SearchEngine.filterByType(db.getItems(), query);
            statusMessage = "Type filter found " + results.size() + " match(es).";
        }

        showResults(results);
        mainWindow.setStatus(statusMessage);
    }

    private void doSort() {
        String field = (String) sortFieldCombo.getSelectedItem();
        String algorithm = (String) algorithmCombo.getSelectedItem();
        List<LibraryItem> items = db.getItems();

        if (algorithm.equals("Insertion Sort")) {
            SortTool.insertionSort(items, field);
        } else {
            SortTool.quickSort(items, field);
        }

        mainWindow.setSortedByTitle(field.equals("Title"));
        mainWindow.setStatus("Sorted " + items.size() + " item(s) by " + field + " using " + algorithm + ".");
        mainWindow.refreshAll();
    }

    private void showResults(List<LibraryItem> results) {
        tableModel.setRows(results);
    }

    public void refresh() {
        this.db = mainWindow.getDb();
        tableModel = new LibraryTableModel(db);
        resultsTable.setModel(tableModel);
        resultsTable.getColumnModel().getColumn(5).setCellRenderer(tableModel.new StatusColumnRenderer());
        tableModel.setRows(db.getItems());
    }
}
