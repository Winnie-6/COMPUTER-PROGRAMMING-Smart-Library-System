package gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.time.LocalDate;
import java.util.List;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

import controller.BorrowController;
import controller.LibraryManager;
import model.Book;
import model.BorrowRecord;
import model.Journal;
import model.LibraryDatabase;
import model.LibraryItem;
import model.Magazine;
import model.UserAccount;
import utils.AccessCache;
import utils.FileHandler;

public class MainWindow extends JFrame {

    private static final String STORAGE_FOLDER = "storage";

    private LibraryDatabase db;
    private LibraryManager manager;
    private BorrowController borrowController;
    private AccessCache cache;
    private boolean sortedByTitle;

    private JLabel statusLabel;
    private ItemsPanel itemsPanel;
    private BorrowPanel borrowPanel;
    private AdminPanel adminPanel;
    private SearchPanel searchPanel;

    private int lastOverdueCount = -1;

    public MainWindow() {
        super("Smart Library Circulation & Automation System");

        db = new LibraryDatabase();
        manager = new LibraryManager(db);
        borrowController = new BorrowController(db);
        cache = new AccessCache();
        sortedByTitle = false;

        boolean loaded = FileHandler.load(STORAGE_FOLDER, db);
        if (!loaded) {
            seedStartingData();
        }

        buildMenuBar();
        buildLayout();
        buildOverdueTimer();

        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                FileHandler.save(STORAGE_FOLDER, db);
                dispose();
                System.exit(0);
            }
        });

        setPreferredSize(new Dimension(950, 650));
        pack();
        setLocationRelativeTo(null);
    }

    private void buildLayout() {
        JTabbedPane tabs = new JTabbedPane();
        itemsPanel = new ItemsPanel(this);
        borrowPanel = new BorrowPanel(this);
        adminPanel = new AdminPanel(this);
        searchPanel = new SearchPanel(this);

        tabs.addTab("View Items", itemsPanel);
        tabs.addTab("Borrow/Return", borrowPanel);
        tabs.addTab("Admin", adminPanel);
        tabs.addTab("Search & Sort", searchPanel);

        statusLabel = new JLabel("Welcome - loaded " + db.getItems().size() + " items.");
        statusLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8));

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(tabs, BorderLayout.CENTER);
        getContentPane().add(statusLabel, BorderLayout.SOUTH);

        refreshAll();
    }

    private void buildMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        fileMenu.setMnemonic(KeyEvent.VK_F);

        JMenuItem saveItem = new JMenuItem("Save");
        saveItem.setMnemonic(KeyEvent.VK_S);
        saveItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        saveItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                FileHandler.save(STORAGE_FOLDER, db);
                setStatus("Saved to " + STORAGE_FOLDER + "/");
            }
        });

        JMenuItem backupItem = new JMenuItem("Backup To...");
        backupItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser();
                chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                int result = chooser.showSaveDialog(MainWindow.this);
                if (result == JFileChooser.APPROVE_OPTION) {
                    String path = chooser.getSelectedFile().getAbsolutePath();
                    FileHandler.save(path, db);
                    setStatus("Backed up to " + path);
                }
            }
        });

        JMenuItem loadItem = new JMenuItem("Load From...");
        loadItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser();
                chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                int result = chooser.showOpenDialog(MainWindow.this);
                if (result == JFileChooser.APPROVE_OPTION) {
                    String path = chooser.getSelectedFile().getAbsolutePath();
                    LibraryDatabase freshDb = new LibraryDatabase();
                    boolean ok = FileHandler.load(path, freshDb);
                    if (!ok) {
                        JOptionPane.showMessageDialog(MainWindow.this,
                                "No library files found in that folder.", "Load failed", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    db = freshDb;
                    manager = new LibraryManager(db);
                    borrowController = new BorrowController(db);
                    markDataChanged();
                    itemsPanel.setDatabase(db);
                    borrowPanel.setDatabase(db);
                    adminPanel.setDatabase(db);
                    searchPanel.setDatabase(db);
                    refreshAll();
                    setStatus("Loaded from " + path);
                }
            }
        });

        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.setMnemonic(KeyEvent.VK_X);
        exitItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                FileHandler.save(STORAGE_FOLDER, db);
                dispose();
                System.exit(0);
            }
        });

        JMenuItem reportsItem = new JMenuItem("Reports");
        reportsItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showReportsDialog();
            }
        });

        fileMenu.add(saveItem);
        fileMenu.add(backupItem);
        fileMenu.add(loadItem);
        fileMenu.addSeparator();
        fileMenu.add(reportsItem);
        fileMenu.addSeparator();
        fileMenu.add(exitItem);

        JMenu helpMenu = new JMenu("Help");
        helpMenu.setMnemonic(KeyEvent.VK_H);
        JMenuItem aboutItem = new JMenuItem("About");
        aboutItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(MainWindow.this,
                        "Smart Library Circulation & Automation System\nBuilt for COS 202.",
                        "About", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        helpMenu.add(aboutItem);

        menuBar.add(fileMenu);
        menuBar.add(helpMenu);
        setJMenuBar(menuBar);
    }

    public void showReportsDialog() {
        String text = manager.buildReportText(LocalDate.now());
        ReportDialog dialog = new ReportDialog(this, text);
        dialog.setVisible(true);
    }

    private void buildOverdueTimer() {
        Timer timer = new Timer(45000, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int count = countOverdue();
                if (count != lastOverdueCount && count > 0) {
                    statusLabel.setForeground(java.awt.Color.RED);
                    statusLabel.setText("Warning: " + count + " item(s) overdue right now.");
                }
                lastOverdueCount = count;
            }
        });
        timer.setInitialDelay(1000);
        timer.start();
    }

    private int countOverdue() {
        int count = 0;
        List<UserAccount> users = db.getUsers();
        LocalDate today = LocalDate.now();
        for (int i = 0; i < users.size(); i++) {
            List<BorrowRecord> history = users.get(i).getHistory();
            for (int j = 0; j < history.size(); j++) {
                if (history.get(j).isOverdue(today)) {
                    count++;
                }
            }
        }
        return count;
    }

    public void setStatus(String message) {
        statusLabel.setForeground(java.awt.Color.BLACK);
        statusLabel.setText(message);
    }

    // any change to the catalog invalidates our "sorted by title" assumption
    public void markDataChanged() {
        sortedByTitle = false;
    }

    public boolean isSortedByTitle() {
        return sortedByTitle;
    }

    public void setSortedByTitle(boolean value) {
        sortedByTitle = value;
    }

    public void refreshAll() {
        itemsPanel.refresh();
        borrowPanel.refresh();
        adminPanel.refresh();
        searchPanel.refresh();
    }

    public LibraryDatabase getDb() {
        return db;
    }

    public LibraryManager getManager() {
        return manager;
    }

    public BorrowController getBorrowController() {
        return borrowController;
    }

    public AccessCache getCache() {
        return cache;
    }

    // fills the catalog with starter data the first time there's nothing saved
    private void seedStartingData() {
        Book b1 = new Book(utils.IDGenerator.nextId("BK"), "Ake: The Years of Childhood", "Wole Soyinka", 1981, "978-0394748204", "Memoir");
        Book b2 = new Book(utils.IDGenerator.nextId("BK"), "The Joys of Motherhood", "Buchi Emecheta", 1979, "978-0435905466", "Fiction");
        Book b3 = new Book(utils.IDGenerator.nextId("BK"), "Weep Not, Child", "Ngugi wa Thiong'o", 1964, "978-0435905005", "Fiction");
        Book b4 = new Book(utils.IDGenerator.nextId("BK"), "The Fishermen", "Chigozie Obioma", 2015, "978-0316338370", "Fiction");
        Book b5 = new Book(utils.IDGenerator.nextId("BK"), "Clean Code", "Robert Martin", 2008, "978-0132350884", "Software Engineering");
        Book b6 = new Book(utils.IDGenerator.nextId("BK"), "Introduction to Algorithms", "Thomas Cormen", 2009, "978-0262033848", "Computer Science");
        db.addItem(b1);
        db.addItem(b2);
        db.addItem(b3);
        db.addItem(b4);
        db.addItem(b5);
        db.addItem(b6);

        Magazine m1 = new Magazine(utils.IDGenerator.nextId("MG"), "African Business", "IC Publications", 2024, 512, "March");
        Magazine m2 = new Magazine(utils.IDGenerator.nextId("MG"), "BBC Science Focus", "Immediate Media", 2024, 402, "June");
        Magazine m3 = new Magazine(utils.IDGenerator.nextId("MG"), "Time", "Time USA", 2024, 4108, "January");
        db.addItem(m1);
        db.addItem(m2);
        db.addItem(m3);

        Journal j1 = new Journal(utils.IDGenerator.nextId("JN"), "Journal of African Economies", "Oxford Academic", 2023, 32, "Economics");
        Journal j2 = new Journal(utils.IDGenerator.nextId("JN"), "Nature", "Springer Nature", 2024, 628, "Science");
        Journal j3 = new Journal(utils.IDGenerator.nextId("JN"), "Computers & Education", "Elsevier", 2023, 195, "Education Technology");
        db.addItem(j1);
        db.addItem(j2);
        db.addItem(j3);

        UserAccount u1 = new UserAccount(utils.IDGenerator.nextId("US"), "Chiamaka Eze");
        UserAccount u2 = new UserAccount(utils.IDGenerator.nextId("US"), "Tunde Bakare");
        UserAccount u3 = new UserAccount(utils.IDGenerator.nextId("US"), "Ifeoma Okafor");
        UserAccount u4 = new UserAccount(utils.IDGenerator.nextId("US"), "Segun Adeyemi");
        UserAccount u5 = new UserAccount(utils.IDGenerator.nextId("US"), "Ngozi Umeh");
        UserAccount u6 = new UserAccount(utils.IDGenerator.nextId("US"), "Femi Balogun");
        UserAccount u7 = new UserAccount(utils.IDGenerator.nextId("US"), "Amina Yusuf");
        db.addUser(u1);
        db.addUser(u2);
        db.addUser(u3);
        db.addUser(u4);
        db.addUser(u5);
        db.addUser(u6);
        db.addUser(u7);

        // one loan that is already overdue, so the reports/timer have something to show
        LocalDate taken = LocalDate.now().minusDays(18);
        LocalDate due = LocalDate.now().minusDays(4);
        BorrowRecord overdueRecord = new BorrowRecord(b3.getItemId(), u3.getUserId(), taken, due);
        u3.addRecord(overdueRecord);
        b3.lendTo(u3.getUserId());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                MainWindow window = new MainWindow();
                window.setVisible(true);
            }
        });
    }
}
