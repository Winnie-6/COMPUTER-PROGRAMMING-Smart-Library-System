package gui;

import java.awt.BorderLayout;
import java.awt.Frame;

import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class ReportDialog extends JDialog {

    public ReportDialog(Frame owner, String reportText) {
        super(owner, "Library Reports", true);

        JTextArea area = new JTextArea(reportText, 20, 50);
        area.setEditable(false);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(new JScrollPane(area), BorderLayout.CENTER);
        pack();
        setLocationRelativeTo(owner);
    }
}
