// "View Items" tab - filterable table, read-only details, popular items list
package gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import controller.SearchEngine;
import model.LibraryDatabase;
import model.LibraryItem;

public class ItemsPanel extends JPanel {

    private MainWindow mainWindow;
    private LibraryDatabase db;

    private JComboBox<String> typeFilterCombo;
    private JTable table;
    private LibraryTableModel tableModel;
    private JTextArea detailsArea;
    private JList<String> popularList;
    private javax.swing.DefaultListModel<String> popularListModel;

    public ItemsPanel(MainWindow mainWindow) {
        this.mainWindow = mainWindow;
        this.db = mainWindow.getDb();
        buildUi();
    }

    public void setDatabase(LibraryDatabase db) {
        this.db = db;
    }

    private void buildUi() {
        setLayout(new BorderLayout(6, 6));

        JPanel topRow = new JPanel();
        JLabel filterLabel = new JLabel("Show:");
        typeFilterCombo = new JComboBox<String>(new String[]{"All", "Book", "Magazine", "Journal"});
        typeFilterCombo.setToolTipText("Filter the shelf by item type");
        filterLabel.setDisplayedMnemonic('S');
        filterLabel.setLabelFor(typeFilterCombo);
        typeFilterCombo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                refresh();
            }
        });
        topRow.add(filterLabel);
        topRow.add(typeFilterCombo);
        add(topRow, BorderLayout.NORTH);

        tableModel = new LibraryTableModel(db);
        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getColumnModel().getColumn(5).setCellRenderer(tableModel.new StatusColumnRenderer());
        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    onRowSelected();
                }
            }
        });
        JScrollPane tableScroll = new JScrollPane(table);

        detailsArea = new JTextArea(8, 24);
        detailsArea.setEditable(false);
        detailsArea.setLineWrap(true);
        detailsArea.setWrapStyleWord(true);
        detailsArea.setToolTipText("Details for the item you have selected");
        JScrollPane detailsScroll = new JScrollPane(detailsArea);
        detailsScroll.setBorder(javax.swing.BorderFactory.createTitledBorder("Details"));

        popularListModel = new javax.swing.DefaultListModel<String>();
        popularList = new JList<String>(popularListModel);
        JScrollPane popularScroll = new JScrollPane(popularList);
        popularScroll.setBorder(javax.swing.BorderFactory.createTitledBorder("Popular Items"));
        popularScroll.setPreferredSize(new Dimension(220, 120));

        JPanel sidePanel = new JPanel(new BorderLayout(4, 4));
        sidePanel.add(detailsScroll, BorderLayout.CENTER);
        sidePanel.add(popularScroll, BorderLayout.SOUTH);
        sidePanel.setPreferredSize(new Dimension(260, 400));

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, tableScroll, sidePanel);
        splitPane.setResizeWeight(0.7);
        add(splitPane, BorderLayout.CENTER);
    }

    private void onRowSelected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            return;
        }
        LibraryItem item = tableModel.itemAt(row);
        if (item == null) {
            return;
        }
        detailsArea.setText(item.getSummary());
        mainWindow.getCache().touch(item.getItemId(), item.getTitle());
        refreshPopularList();
    }

    private void refreshPopularList() {
        popularListModel.clear();
        String[] entries = mainWindow.getCache().topEntries();
        for (int i = 0; i < entries.length; i++) {
            popularListModel.addElement(entries[i]);
        }
    }

    public void refresh() {
        this.db = mainWindow.getDb();
        String type = (String) typeFilterCombo.getSelectedItem();
        List<LibraryItem> shown;
        if (type == null || type.equals("All")) {
            shown = db.getItems();
        } else {
            shown = SearchEngine.filterByType(db.getItems(), type);
        }
        tableModel = new LibraryTableModel(db);
        tableModel.setRows(shown);
        table.setModel(tableModel);
        table.getColumnModel().getColumn(5).setCellRenderer(tableModel.new StatusColumnRenderer());
        refreshPopularList();
    }
}
