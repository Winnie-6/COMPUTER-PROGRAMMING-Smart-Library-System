package gui;

import java.awt.BorderLayout;
import java.awt.Frame;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import model.BorrowRecord;
import model.UserAccount;

public class HistoryDialog extends JDialog {

    public HistoryDialog(Frame owner, UserAccount user) {
        super(owner, "Borrow History - " + user.getFullName(), true);

        JTextArea area = new JTextArea(15, 40);
        area.setEditable(false);

        List<BorrowRecord> history = user.getHistory();
        if (history.isEmpty()) {
            area.setText(user.getFullName() + " hasn't borrowed anything yet.");
        } else {
            StringBuilder text = new StringBuilder();
            for (int i = 0; i < history.size(); i++) {
                BorrowRecord r = history.get(i);
                text.append(r.getItemId()).append("  taken ").append(r.getDateTaken())
                        .append("  due ").append(r.getDateDue());
                if (r.isStillOut()) {
                    text.append("  (still out)");
                } else {
                    text.append("  returned ").append(r.getDateReturned());
                }
                text.append("\n");
            }
            area.setText(text.toString());
        }

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(new JScrollPane(area), BorderLayout.CENTER);
        pack();
        setLocationRelativeTo(owner);
    }
}
