package gui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import model.Book;
import model.Journal;
import model.LibraryDatabase;
import model.LibraryItem;
import model.Magazine;
import utils.IDGenerator;

public class AdminPanel extends JPanel {

    private static final String ADD_CARD = "add";
    private static final String MANAGE_CARD = "manage";

    private MainWindow mainWindow;
    private LibraryDatabase db;

    private CardLayout cardLayout;
    private JPanel cardHolder;

    private JTextField titleField;
    private JTextField authorField;
    private JTextField yearField;
    private JComboBox<String> typeCombo;
    private JLabel extra1Label;
    private JTextField extra1Field;
    private JLabel extra2Label;
    private JTextField extra2Field;

    private JTextField removeIdField;

    public AdminPanel(MainWindow mainWindow) {
        this.mainWindow = mainWindow;
        this.db = mainWindow.getDb();
        buildUi();
    }

    public void setDatabase(LibraryDatabase db) {
        this.db = db;
    }

    private void buildUi() {
        setLayout(new BorderLayout(8, 8));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel switchRow = new JPanel();
        JButton addCardButton = new JButton("Add Item");
        addCardButton.setMnemonic('A');
        addCardButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cardHolder, ADD_CARD);
            }
        });
        JButton manageCardButton = new JButton("Remove & Undo");
        manageCardButton.setMnemonic('R');
        manageCardButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cardHolder, MANAGE_CARD);
            }
        });
        JButton reportsButton = new JButton("Reports");
        reportsButton.setToolTipText("See most borrowed items, overdue users and category counts");
        reportsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mainWindow.showReportsDialog();
            }
        });
        switchRow.add(addCardButton);
        switchRow.add(manageCardButton);
        switchRow.add(reportsButton);
        add(switchRow, BorderLayout.NORTH);

        cardLayout = new CardLayout();
        cardHolder = new JPanel(cardLayout);
        cardHolder.add(buildAddCard(), ADD_CARD);
        cardHolder.add(buildManageCard(), MANAGE_CARD);
        add(cardHolder, BorderLayout.CENTER);
    }

    private JPanel buildAddCard() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createTitledBorder("Add a New Item"));

        titleField = new JTextField();
        authorField = new JTextField();
        yearField = new JTextField();
        typeCombo = new JComboBox<String>(new String[]{"Book", "Magazine", "Journal"});
        extra1Label = new JLabel("ISBN:");
        extra1Field = new JTextField();
        extra2Label = new JLabel("Subject:");
        extra2Field = new JTextField();

        typeCombo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                swapExtraLabels();
            }
        });

        panel.add(fieldRow(new JLabel("Title:"), titleField));
        panel.add(fieldRow(new JLabel("Author:"), authorField));
        panel.add(fieldRow(new JLabel("Year:"), yearField));
        panel.add(fieldRow(new JLabel("Type:"), typeCombo));
        panel.add(fieldRow(extra1Label, extra1Field));
        panel.add(fieldRow(extra2Label, extra2Field));

        JButton addButton = new JButton("Add");
        addButton.setMnemonic('D');
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                doAddItem();
            }
        });
        panel.add(Box.createVerticalStrut(10));
        JPanel buttonRow = new JPanel();
        buttonRow.add(addButton);
        panel.add(buttonRow);
        panel.add(Box.createVerticalGlue());
        return panel;
    }

    private JPanel fieldRow(JLabel label, java.awt.Component field) {
        JPanel row = new JPanel();
        row.setLayout(new BoxLayout(row, BoxLayout.X_AXIS));
        label.setPreferredSize(new java.awt.Dimension(90, 24));
        row.add(label);
        row.add(field);
        row.setAlignmentX(LEFT_ALIGNMENT);
        return row;
    }

    // the two extra fields mean something different for each item type
    private void swapExtraLabels() {
        String type = (String) typeCombo.getSelectedItem();
        if (type.equals("Book")) {
            extra1Label.setText("ISBN:");
            extra2Label.setText("Subject:");
        } else if (type.equals("Magazine")) {
            extra1Label.setText("Issue No:");
            extra2Label.setText("Month:");
        } else {
            extra1Label.setText("Volume No:");
            extra2Label.setText("Field:");
        }
    }

    private JPanel buildManageCard() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createTitledBorder("Remove an Item / Undo"));

        removeIdField = new JTextField();
        panel.add(fieldRow(new JLabel("Item ID:"), removeIdField));

        JButton removeButton = new JButton("Remove");
        removeButton.setMnemonic('M');
        removeButton.setToolTipText("Delete an item that is on the shelf and has nobody waiting for it");
        removeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                doRemoveItem();
            }
        });

        JButton undoButton = new JButton("Undo");
        undoButton.setMnemonic('U');
        undoButton.setToolTipText("Undo the last add or remove");
        undoButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String message = mainWindow.getManager().undoLast();
                mainWindow.markDataChanged();
                mainWindow.setStatus(message);
                mainWindow.refreshAll();
            }
        });

        panel.add(Box.createVerticalStrut(10));
        JPanel buttonRow = new JPanel();
        buttonRow.add(removeButton);
        buttonRow.add(undoButton);
        panel.add(buttonRow);
        panel.add(Box.createVerticalGlue());
        return panel;
    }

    private void doAddItem() {
        String title = titleField.getText().trim();
        String author = authorField.getText().trim();
        String yearText = yearField.getText().trim();
        String extra1 = extra1Field.getText().trim();
        String extra2 = extra2Field.getText().trim();
        String type = (String) typeCombo.getSelectedItem();

        if (title.length() == 0 || author.length() == 0) {
            JOptionPane.showMessageDialog(this, "Title and author are required.", "Missing info", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int year;
        try {
            year = Integer.parseInt(yearText);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Year must be a number.", "Bad input", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (extra2.length() == 0) {
            JOptionPane.showMessageDialog(this, "Please fill in " + extra2Label.getText(), "Missing info", JOptionPane.ERROR_MESSAGE);
            return;
        }

        LibraryItem item = null;
        if (type.equals("Book")) {
            if (extra1.length() == 0) {
                JOptionPane.showMessageDialog(this, "ISBN is required.", "Missing info", JOptionPane.ERROR_MESSAGE);
                return;
            }
            item = new Book(IDGenerator.nextId("BK"), title, author, year, extra1, extra2);
        } else if (type.equals("Magazine")) {
            int issueNo;
            try {
                issueNo = Integer.parseInt(extra1);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Issue No must be a number.", "Bad input", JOptionPane.ERROR_MESSAGE);
                return;
            }
            item = new Magazine(IDGenerator.nextId("MG"), title, author, year, issueNo, extra2);
        } else {
            int volumeNo;
            try {
                volumeNo = Integer.parseInt(extra1);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Volume No must be a number.", "Bad input", JOptionPane.ERROR_MESSAGE);
                return;
            }
            item = new Journal(IDGenerator.nextId("JN"), title, author, year, volumeNo, extra2);
        }

        mainWindow.getManager().addItem(item);
        mainWindow.markDataChanged();
        mainWindow.setStatus(item.getTitle() + " added as " + item.getItemId() + ".");
        mainWindow.refreshAll();

        titleField.setText("");
        authorField.setText("");
        yearField.setText("");
        extra1Field.setText("");
        extra2Field.setText("");
    }

    private void doRemoveItem() {
        String itemId = removeIdField.getText().trim();
        if (itemId.length() == 0) {
            JOptionPane.showMessageDialog(this, "Type the id of the item to remove.", "Missing info", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String message = mainWindow.getManager().removeItem(itemId);
        mainWindow.markDataChanged();
        mainWindow.setStatus(message);
        mainWindow.refreshAll();
        removeIdField.setText("");
    }

    public void refresh() {
        this.db = mainWindow.getDb();
    }
}
