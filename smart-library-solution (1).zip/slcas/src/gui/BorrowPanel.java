package gui;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import model.LibraryDatabase;
import model.LibraryItem;
import model.UserAccount;

public class BorrowPanel extends JPanel {

    private MainWindow mainWindow;
    private LibraryDatabase db;

    private JComboBox<String> borrowItemCombo;
    private JComboBox<String> borrowUserCombo;
    private JComboBox<String> returnItemCombo;
    private JComboBox<String> historyUserCombo;

    public BorrowPanel(MainWindow mainWindow) {
        this.mainWindow = mainWindow;
        this.db = mainWindow.getDb();
        buildUi();
    }

    public void setDatabase(LibraryDatabase db) {
        this.db = db;
    }

    private void buildUi() {
        setLayout(new GridLayout(1, 2, 10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(buildBorrowForm());
        add(buildReturnForm());
    }

    private JPanel buildBorrowForm() {
        JPanel panel = new JPanel();
        panel.setLayout(new javax.swing.BoxLayout(panel, javax.swing.BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createTitledBorder("Borrow an Item"));

        JLabel itemLabel = new JLabel("Item:");
        borrowItemCombo = new JComboBox<String>();
        borrowItemCombo.setToolTipText("Pick the item to lend out");

        JLabel userLabel = new JLabel("Borrower:");
        borrowUserCombo = new JComboBox<String>();
        borrowUserCombo.setToolTipText("Pick who is borrowing it");

        JButton borrowButton = new JButton("Borrow");
        borrowButton.setMnemonic('B');
        borrowButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                doBorrow();
            }
        });

        JButton historyButton = new JButton("View History");
        historyButton.setToolTipText("See everything this user has borrowed");
        historyButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                doViewHistory();
            }
        });

        panel.add(itemLabel);
        panel.add(borrowItemCombo);
        panel.add(javax.swing.Box.createVerticalStrut(8));
        panel.add(userLabel);
        panel.add(borrowUserCombo);
        panel.add(javax.swing.Box.createVerticalStrut(12));
        panel.add(borrowButton);
        panel.add(javax.swing.Box.createVerticalStrut(6));
        panel.add(historyButton);
        panel.add(javax.swing.Box.createVerticalGlue());
        return panel;
    }

    private JPanel buildReturnForm() {
        JPanel panel = new JPanel();
        panel.setLayout(new javax.swing.BoxLayout(panel, javax.swing.BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createTitledBorder("Return an Item"));

        JLabel itemLabel = new JLabel("Item currently out:");
        returnItemCombo = new JComboBox<String>();
        returnItemCombo.setToolTipText("Pick the item being returned");

        JButton returnButton = new JButton("Return");
        returnButton.setMnemonic('R');
        returnButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                doReturn();
            }
        });

        panel.add(itemLabel);
        panel.add(returnItemCombo);
        panel.add(javax.swing.Box.createVerticalStrut(12));
        panel.add(returnButton);
        panel.add(javax.swing.Box.createVerticalGlue());
        return panel;
    }

    private void doBorrow() {
        String itemChoice = (String) borrowItemCombo.getSelectedItem();
        String userChoice = (String) borrowUserCombo.getSelectedItem();
        if (itemChoice == null || userChoice == null) {
            JOptionPane.showMessageDialog(this, "Pick both an item and a borrower first.", "Missing info", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String itemId = idFromChoice(itemChoice);
        String userId = idFromChoice(userChoice);
        String message = mainWindow.getBorrowController().processBorrow(itemId, userId, LocalDate.now());
        mainWindow.markDataChanged();
        mainWindow.setStatus(message);
        mainWindow.refreshAll();
    }

    private void doReturn() {
        String itemChoice = (String) returnItemCombo.getSelectedItem();
        if (itemChoice == null) {
            JOptionPane.showMessageDialog(this, "Pick an item to return first.", "Missing info", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String itemId = idFromChoice(itemChoice);
        String message = mainWindow.getBorrowController().processReturn(itemId, LocalDate.now());
        mainWindow.markDataChanged();
        mainWindow.setStatus(message);
        mainWindow.refreshAll();
    }

    private void doViewHistory() {
        String userChoice = (String) borrowUserCombo.getSelectedItem();
        if (userChoice == null) {
            JOptionPane.showMessageDialog(this, "Pick a user first.", "Missing info", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String userId = idFromChoice(userChoice);
        UserAccount user = db.getUser(userId);
        if (user == null) {
            return;
        }
        HistoryDialog dialog = new HistoryDialog(mainWindow, user);
        dialog.setVisible(true);
    }

    private String idFromChoice(String choice) {
        int dash = choice.indexOf(" - ");
        if (dash < 0) {
            return choice;
        }
        return choice.substring(0, dash);
    }

    public void refresh() {
        this.db = mainWindow.getDb();

        borrowItemCombo.removeAllItems();
        List<LibraryItem> items = db.getItems();
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).isOnShelf()) {
                borrowItemCombo.addItem(items.get(i).getItemId() + " - " + items.get(i).getTitle());
            }
        }

        returnItemCombo.removeAllItems();
        for (int i = 0; i < items.size(); i++) {
            if (!items.get(i).isOnShelf()) {
                returnItemCombo.addItem(items.get(i).getItemId() + " - " + items.get(i).getTitle());
            }
        }

        borrowUserCombo.removeAllItems();
        List<UserAccount> users = db.getUsers();
        for (int i = 0; i < users.size(); i++) {
            borrowUserCombo.addItem(users.get(i).getUserId() + " - " + users.get(i).getFullName());
        }
    }
}
