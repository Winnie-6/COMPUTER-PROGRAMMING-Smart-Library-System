package gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;

import model.BorrowRecord;
import model.LibraryDatabase;
import model.LibraryItem;

public class LibraryTableModel extends AbstractTableModel {

    private static final String[] COLUMN_NAMES = {"ID", "Type", "Title", "Author", "Year", "Status"};

    private List<LibraryItem> rows;
    private LibraryDatabase db;

    public LibraryTableModel(LibraryDatabase db) {
        this.db = db;
        this.rows = new ArrayList<LibraryItem>();
    }

    public void setRows(List<LibraryItem> newRows) {
        this.rows = newRows;
        fireTableDataChanged();
    }

    public LibraryItem itemAt(int rowIndex) {
        if (rowIndex < 0 || rowIndex >= rows.size()) {
            return null;
        }
        return rows.get(rowIndex);
    }

    public int getRowCount() {
        return rows.size();
    }

    public int getColumnCount() {
        return COLUMN_NAMES.length;
    }

    public String getColumnName(int col) {
        return COLUMN_NAMES[col];
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        LibraryItem item = rows.get(rowIndex);
        switch (columnIndex) {
            case 0: return item.getItemId();
            case 1: return item.getType();
            case 2: return item.getTitle();
            case 3: return item.getAuthor();
            case 4: return item.getYear();
            case 5: return statusText(item);
            default: return "";
        }
    }

    private String statusText(LibraryItem item) {
        if (item.isOnShelf()) {
            return "In";
        }
        BorrowRecord record = db.activeRecordFor(item.getItemId());
        if (record != null && record.isOverdue(LocalDate.now())) {
            return "Overdue";
        }
        return "Lent to " + item.getCurrentHolder();
    }

    // paints only the Status column - green when in, blue when lent, red when overdue
    public class StatusColumnRenderer extends DefaultTableCellRenderer {
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                boolean hasFocus, int row, int column) {
            JLabel label = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            String text = value == null ? "" : value.toString();
            if (text.equals("In")) {
                label.setForeground(new Color(0, 100, 0));
                label.setFont(label.getFont().deriveFont(Font.PLAIN));
            } else if (text.equals("Overdue")) {
                label.setForeground(new Color(180, 0, 0));
                label.setFont(label.getFont().deriveFont(Font.BOLD));
            } else if (text.startsWith("Lent to")) {
                label.setForeground(new Color(0, 0, 180));
                label.setFont(label.getFont().deriveFont(Font.BOLD));
            } else {
                label.setForeground(table.getForeground());
                label.setFont(label.getFont().deriveFont(Font.PLAIN));
            }
            return label;
        }
    }
}
