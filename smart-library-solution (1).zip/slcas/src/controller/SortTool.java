// two sorting algorithms we can run on the item list - insertion and quick
package controller;

import java.util.List;

import model.LibraryItem;

public class SortTool {

    private SortTool() {
    }

    public static void insertionSort(List<LibraryItem> items, String field) {
        for (int i = 1; i < items.size(); i++) {
            LibraryItem key = items.get(i);
            int j = i - 1;
            while (j >= 0 && compare(items.get(j), key, field) > 0) {
                items.set(j + 1, items.get(j));
                j--;
            }
            items.set(j + 1, key);
        }
    }

    public static void quickSort(List<LibraryItem> items, String field) {
        if (items.size() < 2) {
            return;
        }
        quickSortRange(items, 0, items.size() - 1, field);
    }

    private static void quickSortRange(List<LibraryItem> items, int low, int high, String field) {
        if (low >= high) {
            return;
        }
        int splitPoint = partition(items, low, high, field);
        quickSortRange(items, low, splitPoint - 1, field);
        quickSortRange(items, splitPoint + 1, high, field);
    }

    private static int partition(List<LibraryItem> items, int low, int high, String field) {
        LibraryItem pivot = items.get(high);
        int boundary = low - 1;
        for (int i = low; i < high; i++) {
            if (compare(items.get(i), pivot, field) <= 0) {
                boundary++;
                swap(items, boundary, i);
            }
        }
        swap(items, boundary + 1, high);
        return boundary + 1;
    }

    private static void swap(List<LibraryItem> items, int a, int b) {
        LibraryItem temp = items.get(a);
        items.set(a, items.get(b));
        items.set(b, temp);
    }

    // switches on which field the user picked to sort by
    private static int compare(LibraryItem a, LibraryItem b, String field) {
        if (field.equalsIgnoreCase("author")) {
            return a.getAuthor().compareToIgnoreCase(b.getAuthor());
        } else if (field.equalsIgnoreCase("year")) {
            return Integer.compare(a.getYear(), b.getYear());
        } else {
            return a.getTitle().compareToIgnoreCase(b.getTitle());
        }
    }
}
