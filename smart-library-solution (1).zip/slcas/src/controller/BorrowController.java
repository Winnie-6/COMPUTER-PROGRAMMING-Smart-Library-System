// runs the actual borrow/return flow, waitlist handoff and fine math
package controller;

import java.time.LocalDate;

import model.BorrowRecord;
import model.LibraryDatabase;
import model.LibraryItem;
import model.UserAccount;

public class BorrowController {

    public static final int MAX_ACTIVE_LOANS = 4;
    public static final int FINE_PER_DAY = 100;

    private LibraryDatabase db;

    public BorrowController(LibraryDatabase db) {
        this.db = db;
    }

    // tries to lend the item out, or puts the user on the waitlist if item is already borrowed
    public String processBorrow(String itemId, String userId, LocalDate today) {
        LibraryItem item = db.getItem(itemId);
        UserAccount user = db.getUser(userId);
        if (item == null) {
            return "That item id doesn't exist.";
        }
        if (user == null) {
            return "That user id doesn't exist.";
        }
        if (user.activeLoanCount() >= MAX_ACTIVE_LOANS) {
            return user.getFullName() + " already has " + MAX_ACTIVE_LOANS + " items out...can't borrow more.";
        }
        if (item.isOnShelf()) {
            LocalDate due = today.plusDays(item.borrowDays());
            BorrowRecord record = new BorrowRecord(item.getItemId(), user.getUserId(), today, due);
            user.addRecord(record);
            item.lendTo(user.getUserId());
            return item.getTitle() + " lent to " + user.getFullName() + ", due back " + due + ".";
        } else {
            db.joinWaitlist(itemId, userId);
            return item.getTitle() + " is already out - " + user.getFullName() + " was added to the waitlist.";
        }
    }

    // closes out the loan and, if anyone is waiting, hands the item straight to them
    public String processReturn(String itemId, LocalDate today) {
        LibraryItem item = db.getItem(itemId);
        if (item == null) {
            return "That item id doesn't exist.";
        }
        BorrowRecord record = db.activeRecordFor(itemId);
        if (record == null) {
            return item.getTitle() + " isn't currently out.";
        }
        record.setDateReturned(today);
        item.handBack();

        StringBuilder message = new StringBuilder();
        int lateDays = record.daysLate(today);
        if (lateDays > 0) {
            message.append(item.getTitle()).append(" returned ").append(lateDays)
                    .append(" day(s) late. Fine: ").append(fineFor(lateDays)).append(" naira. ");
        } else {
            message.append(item.getTitle()).append(" returned on time. ");
        }

        String handoffNote = handOffToWaitlist(item, today);
        message.append(handoffNote);
        return message.toString();
    }

    // walk the waitlist until we find someone who can actually take the item
    private String handOffToWaitlist(LibraryItem item, LocalDate today) {
        String nextUserId = db.nextInWaitlist(item.getItemId());
        while (nextUserId != null) {
            UserAccount candidate = db.getUser(nextUserId);
            if (candidate == null || candidate.activeLoanCount() >= MAX_ACTIVE_LOANS) {
                // this person can't take it right now, drop them and try the next
                nextUserId = db.nextInWaitlist(item.getItemId());
                continue;
            }
            LocalDate due = today.plusDays(item.borrowDays());
            BorrowRecord record = new BorrowRecord(item.getItemId(), candidate.getUserId(), today, due);
            candidate.addRecord(record);
            item.lendTo(candidate.getUserId());
            return "Handed straight to " + candidate.getFullName() + " from the waitlist.";
        }
        return "";
    }

    // 100 naira for every day late, added up one day at a time
    public static int fineFor(int daysLate) {
        int total = 0;
        for (int i = 0; i < daysLate; i++) {
            total += FINE_PER_DAY;
        }
        return total;
    }
}
