// linear title search, iterative binary title search, recursive author search
package controller;

import java.util.ArrayList;
import java.util.List;

import model.LibraryItem;

public class SearchEngine {

    private SearchEngine() {
    }

    // walks the whole list looking for the title
    public static List<LibraryItem> linearTitleSearch(List<LibraryItem> items, String query) {
        List<LibraryItem> found = new ArrayList<LibraryItem>();
        String needle = query.toLowerCase();
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).getTitle().toLowerCase().contains(needle)) {
                found.add(items.get(i));
            }
        }
        return found;
    }

    // needs the list to already be sorted by title
    public static List<LibraryItem> binaryTitleSearch(List<LibraryItem> items, String query) {
        List<LibraryItem> found = new ArrayList<LibraryItem>();
        String needle = query.toLowerCase();
        int lo = 0;
        int hi = items.size() - 1;
        int landedAt = -1;

        while (lo <= hi) {
            int mid = (lo + hi) / 2;
            String midTitle = items.get(mid).getTitle().toLowerCase();
            int cmp = midTitle.compareTo(needle);
            if (cmp == 0) {
                landedAt = mid;
                break;
            } else if (cmp < 0) {
                lo = mid + 1;
            } else {
                hi = mid - 1;
            }
        }

        if (landedAt == -1) {
            return found;
        }

        // an exact hit might have neighbours with the same title, so sweep both ways
        found.add(items.get(landedAt));
        int left = landedAt - 1;
        while (left >= 0 && items.get(left).getTitle().equalsIgnoreCase(query)) {
            found.add(items.get(left));
            left--;
        }
        int right = landedAt + 1;
        while (right < items.size() && items.get(right).getTitle().equalsIgnoreCase(query)) {
            found.add(items.get(right));
            right++;
        }
        return found;
    }

    // recurses one index at a time collecting every author match it sees
    public static void searchAuthor(List<LibraryItem> items, String query, int index, List<LibraryItem> found) {
        if (index >= items.size()) {
            return;
        }
        if (items.get(index).getAuthor().toLowerCase().contains(query.toLowerCase())) {
            found.add(items.get(index));
        }
        searchAuthor(items, query, index + 1, found);
    }

    public static List<LibraryItem> filterByType(List<LibraryItem> items, String type) {
        List<LibraryItem> found = new ArrayList<LibraryItem>();
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).getType().toLowerCase().startsWith(type.toLowerCase())) {
                found.add(items.get(i));
            }
        }
        return found;
    }
}
