// admin-side operations: add/remove items, undo, and the three reports
package controller;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Stack;

import model.BorrowRecord;
import model.LibraryDatabase;
import model.LibraryItem;
import model.UserAccount;

public class LibraryManager {

    // one thing we did, so we can walk it back later
    private class LastAction {
        String kind; // "ADD" or "REMOVE"
        LibraryItem thing;

        LastAction(String kind, LibraryItem thing) {
            this.kind = kind;
            this.thing = thing;
        }
    }

    private LibraryDatabase db;
    private Stack<LastAction> undoStack;

    public LibraryManager(LibraryDatabase db) {
        this.db = db;
        this.undoStack = new Stack<LastAction>();
    }

    public void addItem(LibraryItem item) {
        db.addItem(item);
        undoStack.push(new LastAction("ADD", item));
    }

    // won't delete something that's out on loan or has people waiting for it
    public String removeItem(String itemId) {
        LibraryItem item = db.getItem(itemId);
        if (item == null) {
            return "No item with that id.";
        }
        if (!item.isOnShelf()) {
            return "Can't remove " + item.getTitle() + " - it's currently lent out.";
        }
        if (db.hasWaitlist(itemId)) {
            return "Can't remove " + item.getTitle() + " - people are waiting for it.";
        }
        db.removeItem(itemId);
        db.clearWaitlist(itemId);
        undoStack.push(new LastAction("REMOVE", item));
        return item.getTitle() + " removed.";
    }

    public String undoLast() {
        if (undoStack.isEmpty()) {
            return "Nothing to undo yet.";
        }
        LastAction last = undoStack.peek();
        if (last.kind.equals("ADD")) {
            if (!last.thing.isOnShelf()) {
                return "Can't undo adding " + last.thing.getTitle() + " - it's already lent out.";
            }
            undoStack.pop();
            db.removeItem(last.thing.getItemId());
            db.clearWaitlist(last.thing.getItemId());
            return "Undid adding " + last.thing.getTitle() + ".";
        } else {
            undoStack.pop();
            db.addItem(last.thing);
            return "Undid removing " + last.thing.getTitle() + " - it's back on the shelf.";
        }
    }

    // three-part text report: most borrowed, overdue users, items per category
    public String buildReportText(LocalDate today) {
        StringBuilder text = new StringBuilder();

        text.append("== Most Borrowed Items ==\n");
        List<LibraryItem> items = db.getItems();
        for (int i = 0; i < items.size(); i++) {
            LibraryItem item = items.get(i);
            int timesBorrowed = countBorrowsFor(item.getItemId());
            text.append(item.getItemId()).append(" - ").append(item.getTitle())
                    .append(" : ").append(timesBorrowed).append(" loan(s)\n");
        }

        text.append("\n== Users With Overdue Items ==\n");
        boolean anyOverdue = false;
        List<UserAccount> users = db.getUsers();
        for (int i = 0; i < users.size(); i++) {
            UserAccount user = users.get(i);
            List<BorrowRecord> history = user.getHistory();
            for (int j = 0; j < history.size(); j++) {
                BorrowRecord record = history.get(j);
                if (record.isOverdue(today)) {
                    anyOverdue = true;
                    text.append(user.getFullName()).append(" (").append(user.getUserId()).append(") - ")
                            .append(record.getItemId()).append(", ").append(record.daysLate(today))
                            .append(" day(s) late\n");
                }
            }
        }
        if (!anyOverdue) {
            text.append("Nobody is overdue right now.\n");
        }

        text.append("\n== Items Per Category ==\n");
        HashMap<String, Integer> categoryCounts = new HashMap<String, Integer>();
        for (int i = 0; i < items.size(); i++) {
            String type = items.get(i).getType();
            Integer soFar = categoryCounts.get(type);
            if (soFar == null) {
                categoryCounts.put(type, 1);
            } else {
                categoryCounts.put(type, soFar + 1);
            }
        }
        for (String type : categoryCounts.keySet()) {
            text.append(type).append(": ").append(categoryCounts.get(type)).append("\n");
        }

        return text.toString();
    }

    private int countBorrowsFor(String itemId) {
        int total = 0;
        List<UserAccount> users = db.getUsers();
        for (int i = 0; i < users.size(); i++) {
            List<BorrowRecord> history = users.get(i).getHistory();
            for (int j = 0; j < history.size(); j++) {
                if (history.get(j).getItemId().equals(itemId)) {
                    total++;
                }
            }
        }
        return total;
    }
}
