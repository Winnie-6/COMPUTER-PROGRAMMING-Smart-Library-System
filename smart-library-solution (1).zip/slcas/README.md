# SLCAS - Smart Library Circulation & Automation System

A desktop Java Swing app for running a small library, cataloguing items, borrowing and returning them, reservation waitlists, an undo stack for admin actions, search, sorting, and simple usage reports.

## Requirements

Java 17 or newe

## Run

from the root of the repo

```sh
javac -d out $(find src -name '*.java')
java -cp out gui.MainWindow
```
